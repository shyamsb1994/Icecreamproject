﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using icecreamproject.Models;
using System.Data.SqlClient;
using icecreamproject.DA;
using Newtonsoft.Json;
using icecreamproject.UsefulMeathods;
using icecreamproject.Filters;

namespace icecreamproject.Controllers
{
    
    public class UserController:Controller
    {
        public ActionResult register()
        {
            UserDA userda = new UserDA();
            SelectList lst = new SelectList(userda.getmembershipdata(), "mem_id", "mem_type");
            ViewBag.subscriptions = lst;
            return View();
        }
        [HttpPost]
        public ActionResult register(usermodel um,HttpPostedFileBase u_image)
        {
             
            if (ModelState.IsValid)
            {
                ImageMeathods imgmeathods = new ImageMeathods();
                imgmeathods.StoreImage(u_image);
                um.u_image = u_image.FileName;
                string jsondata = JsonConvert.SerializeObject(um);
                UserDA da = new UserDA();
              da.storeuserdata(jsondata);
            }
           return RedirectToAction("successfull");
        }
      
        public ActionResult successfull()
        {
            return View();
        }
        
        public ActionResult SignIN()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SignIN(LogonModel logondetails)
        {
            UserDA userda = new UserDA();
           bool result= userda.CheckValidUser(logondetails);
            if (result == true)
            {
                Session["username"] = logondetails.Username;
                return RedirectToAction("userpanel", "user");
            }
            return RedirectToAction("register", "user");
        }
        public ActionResult userpanel()
        {
            if (Session["username"] != null)
            {
                UserDA userda = new UserDA();
                List<RecepieModel> recepies = userda.getallrecepies();
                return View(recepies);
            }

            return RedirectToAction("SignIN");
        }
        public ActionResult signout()
        {
            Session.Abandon();
            Session.Clear();

            return RedirectToAction("SignIN");
        }
        public ActionResult Feedback(string message=null)
        {
            if (message != null)
            {
                ViewBag.message = message;
            }
            return View("UserFeedback");
        }
        [HttpPost]
        public ActionResult Feedback(FeedbackModel feedbackmodel)
        {
            string data = Newtonsoft.Json.JsonConvert.SerializeObject(feedbackmodel);
            UserDA userda = new UserDA();
            userda.storefeedback(data);
     
            return RedirectToAction("Feedback",new{message="feedback submitted successfully" });
        }
    }
}