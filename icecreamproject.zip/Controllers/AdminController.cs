﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using icecreamproject.DA;
using icecreamproject.Models;
using icecreamproject.UsefulMeathods;
using PagedList;


namespace icecreamproject.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Feedback(int page=1)
        {
            AdminDA adminda = new AdminDA();
            List<FeedbackModel> feedbacks= adminda.getfeedbackdata();
            IPagedList griddata = feedbacks.ToPagedList(page, 3);
            ViewBag.page = griddata;
            return View(griddata);
        }
        public ActionResult CreateRecepies()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateRecepies(RecepieModel recepiemodel,HttpPostedFileBase recepieimage)
        {
            AdminDA adminda = new AdminDA();
            UsefulMeathods.ImageMeathods imgmeathods = new ImageMeathods();
            imgmeathods.StoreImage(recepieimage);
            recepiemodel.image = recepieimage.FileName;
            string jsondata = Newtonsoft.Json.JsonConvert.SerializeObject(recepiemodel);
            adminda.CreateRecepies(jsondata);
            return RedirectToAction("CreateRecepies");
        }
        public ActionResult PerformAction(string selectedrow,string actionid)
        {
            if (Convert.ToInt32(actionid) == 0)
            {
                AdminDA adminda = new AdminDA();
                List<FeedbackModel> feedbacks = adminda.getfeedbackdata();
                return View("Edit",feedbacks.Find(x => x.id == Convert.ToInt32(selectedrow)));
            }
            else
            {
                AdminDA adminda = new AdminDA();
                adminda.DeleteFeedback(Convert.ToInt32(selectedrow));
                return RedirectToAction("Feedback");
            }
        }
        [HttpPost]
        public ActionResult PerformAction(FeedbackModel feedbackmodel)
        {
            AdminDA admnda = new AdminDA();
            admnda.UpdateFeedback(feedbackmodel);
           return RedirectToAction("Feedback");

        }
       
        public ActionResult ShowPriorityFeedbacks()
        {
            AdminDA admnda = new AdminDA();
           List<FeedbackModel> data= admnda.ShowPriorityFeedbacks();
            return View(data);

        }

        public ActionResult SearchData(string searctxt,string searchdata)
        {
            AdminDA admnda = new AdminDA();
           List<FeedbackModel> srchdata= admnda.SearchData(searctxt, searchdata);
            return View(srchdata);
        }

    }
}