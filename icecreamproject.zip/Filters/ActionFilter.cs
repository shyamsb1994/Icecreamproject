﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using icecreamproject.UsefulMeathods;
namespace icecreamproject.Filters
{
    public class ActionFilter: System.Web.Mvc.ActionFilterAttribute
    {
        public override void OnActionExecuted(System.Web.Mvc.ActionExecutedContext filterContext)
        {
          
        }
        public override void OnActionExecuting(System.Web.Mvc.ActionExecutingContext filterContext)
        {
            Logger logger = new Logger();
            logger.WriteLog(filterContext.ActionParameters);
        }
        public override void OnResultExecuted(System.Web.Mvc.ResultExecutedContext filterContext)
        {
            Logger logger = new Logger();
            logger.WriteLog(filterContext.Result);
        }
        public override void OnResultExecuting(System.Web.Mvc.ResultExecutingContext filterContext)
        {

        }
    }
}