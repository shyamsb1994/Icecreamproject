﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace icecreamproject.Models
{
    public class usermodel
    {
        [System.Web.Mvc.HiddenInput(DisplayValue = false)]
        public int u_id { get; set; }
        [Display(Name = "USERNAME")]
        [Required(ErrorMessage = "plz enter the name")]
        public string u_name { get; set; }
        [Display(Name = "EMAIL")]
        [Required(ErrorMessage = "plz enter the email")]
        public string u_email { get; set; }
        [Required(ErrorMessage = "plz enter the password")]
        [Display(Name = "PASSWORD")]
        public string u_password { get; set; }
        [Display(Name = "PROFILE")]
        [Required(ErrorMessage = "plz enter the image")]
        public string u_image { get; set; }
        [Compare("u_password")]
        public string CONFORMPASSWORD { get; set; }
        [Display(Name = "CONTACT")]
        [Required(ErrorMessage = "plz enter the contact")]
        public string u_contact { get; set; }
        [Display(Name = "SUBSCRIBE")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "plz enter the subscriber")]
        public int u_sub { get; set; }
    }
}