﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace icecreamproject.Models
{
    public class MembershipModel
    {
      public int mem_id { get; set; }
      public int mem_payment { get; set; }
      public string mem_type { get; set; }
    }
}