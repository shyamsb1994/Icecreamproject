﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace icecreamproject.Models
{
    public class FeedbackModel
    {
        [System.Web.Mvc.HiddenInput]
        public int id { get; set; }
        [Required]
        public string name { get; set; }
        [Required]
        public string feedback { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        public string email { get; set; }
        [Required]
        public string contact { get; set; }
    }
}