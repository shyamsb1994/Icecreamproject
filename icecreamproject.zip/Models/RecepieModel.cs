﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace icecreamproject.Models
{
    public class RecepieModel
    {
        [System.Web.Mvc.HiddenInput]
        public int id { get; set; }
        [Required(ErrorMessage ="plz enter the name of the recepie")]
        public string name { get; set; }
        [Required(AllowEmptyStrings =false)]
        public string image { get; set; }
        [Required]
        public string recepie { get; set; }
    }
}