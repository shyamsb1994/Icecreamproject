﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using icecreamproject.Models;
using Newtonsoft.Json;

namespace icecreamproject.DA
{
    public class UserDA
    {
        public bool RegisterUser()
        {
            string DBCon = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(DBCon);
            SqlCommand cmd = new SqlCommand("",conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            return true;
        }
        public List<MembershipModel> getmembershipdata()
        {
            string DBCon = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(DBCon);
            SqlCommand cmd = new SqlCommand("select * from table_membership", conn);
            conn.Open();
            SqlDataReader rdr= cmd.ExecuteReader();
            List<MembershipModel> subscription = new List<MembershipModel>();
            while (rdr.Read())
            {
                MembershipModel temp = new MembershipModel();
                temp.mem_id = Convert.ToInt32(rdr["mem_id"]);
                temp.mem_payment = Convert.ToInt32(rdr["mem_payment"]);
                temp.mem_type = Convert.ToString(rdr["mem_type"]);
                subscription.Add(temp);
            }
            conn.Close();
            return subscription;
        }
        public void storeuserdata(string jsondata)
        {
           
                string DBCon = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
                SqlConnection conn = new SqlConnection(DBCon);
                SqlCommand cmd = new SqlCommand("insertuserdata", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("@jsondata", System.Data.SqlDbType.NVarChar);
                cmd.Parameters["@jsondata"].Value = jsondata;
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            
         
        }
        public bool CheckValidUser(LogonModel logondetails)
        {
            string DBCon = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(DBCon);
            SqlCommand cmd = new SqlCommand("select * from table_user", conn);
            conn.Open();
            SqlDataReader rdr= cmd.ExecuteReader();
            List<usermodel> userlist = new List<usermodel>();
            while (rdr.Read())
            {
                usermodel usermodel = new usermodel();
                usermodel.u_name = rdr["u_name"].ToString();
                usermodel.u_password = rdr["u_password"].ToString();
                usermodel.u_email = rdr["u_email"].ToString();
                userlist.Add(usermodel);
            }
            conn.Close();
           usermodel userinfo= userlist.Find(x => (x.u_name == logondetails.Username) && (x.u_password == logondetails.Password));
           return userlist.Exists(x => (x.u_name == logondetails.Username) && (x.u_password == logondetails.Password));
            
        }
        
        public void storefeedback(string jsondata)
        {
            string con = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("storefeedback",conn);
            cmd.CommandType=System.Data.CommandType.StoredProcedure;
            cmd.Parameters.Add("@jsondata",System.Data.SqlDbType.NVarChar);
            cmd.Parameters["@jsondata"].Value = jsondata;
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public List<RecepieModel> getallrecepies()
        {
            string con = System.Configuration.ConfigurationManager.ConnectionStrings["DbCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("select * From table_recepie", conn);
            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            List<RecepieModel> recepiemodel = new List<RecepieModel>();
            while (rdr.Read())
            {
                RecepieModel model = new RecepieModel();
                model.name = rdr["name"].ToString();
                model.recepie = rdr["recepie"].ToString();
                model.image = rdr["image"].ToString();
                model.id = Convert.ToInt32(rdr["id"]);
                recepiemodel.Add(model);
            }
            conn.Close();
            return recepiemodel;
        }
    }
}