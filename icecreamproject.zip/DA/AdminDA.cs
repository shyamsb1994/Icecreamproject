﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using icecreamproject.Models;
using System.Data.SqlClient;

namespace icecreamproject.DA
{
    public class AdminDA
    {
        public List<FeedbackModel> getfeedbackdata()
        {
            string con = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("select * from table_feedback",conn);
            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            List<FeedbackModel> feedbacks = new List<FeedbackModel>();
            while (rdr.Read())
            {
                FeedbackModel model = new FeedbackModel();
                model.contact = rdr["contact"].ToString();
                model.name = rdr["name"].ToString();
                model.id = Convert.ToInt32(rdr["id"]);
                model.email = rdr["email"].ToString();
                model.feedback = rdr["feedback"].ToString();
                feedbacks.Add(model);
            }
            return feedbacks;
        }

        
        public void CreateRecepies(string jsondata)
        {

            string con = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("storerecepie", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.Add("@json", System.Data.SqlDbType.NVarChar);
            cmd.Parameters["@json"].Value = jsondata;
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public void DeleteFeedback(int selectedid)
        {
            string con = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("delete from table_feedback where id=@selectedid", conn);
            cmd.Parameters.Add("@selectedid", System.Data.SqlDbType.Int);
            cmd.Parameters["@selectedid"].Value = selectedid;
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public void  UpdateFeedback(FeedbackModel feedbackModel)
        {
            string con = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("update table_feedback set name=@name,feedback=@feedback,email=@email,contact=@contact where id=@id", conn);
            cmd.Parameters.Add("@name", System.Data.SqlDbType.NVarChar);
            cmd.Parameters["@name"].Value = feedbackModel.name;
            cmd.Parameters.Add("@feedback", System.Data.SqlDbType.NVarChar);
            cmd.Parameters["@feedback"].Value = feedbackModel.feedback;
            cmd.Parameters.Add("@email", System.Data.SqlDbType.NVarChar);
            cmd.Parameters["@email"].Value = feedbackModel.email;
            cmd.Parameters.Add("@contact", System.Data.SqlDbType.NVarChar);
            cmd.Parameters["@contact"].Value = feedbackModel.contact;
            cmd.Parameters.Add("@id", System.Data.SqlDbType.NVarChar);
            cmd.Parameters["@id"].Value = feedbackModel.id;
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public List<FeedbackModel> ShowPriorityFeedbacks()
        {
            string con = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("   select* from table_feedback inner join table_user on table_feedback.name=table_user.u_name", conn);

            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            List<FeedbackModel> feedbacks = new List<FeedbackModel>();
            while (rdr.Read())
            {
                FeedbackModel model = new FeedbackModel();
                model.contact = rdr["contact"].ToString();
                model.name = rdr["name"].ToString();
                model.id = Convert.ToInt32(rdr["id"]);
                model.email = rdr["email"].ToString();
                model.feedback = rdr["feedback"].ToString();
                feedbacks.Add(model);
            }
            return feedbacks;
        }

        public List<FeedbackModel> SearchData(string searctxt,string searchdata)
        {
            string con = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
            SqlConnection conn = new SqlConnection(con);
            SqlCommand cmd;
            if (searctxt == "name") {
                cmd = new SqlCommand("select* from table_feedback where name=@searchdata", conn);
                cmd.Parameters.Add("@searchdata", System.Data.SqlDbType.NVarChar);
                cmd.Parameters["@searchdata"].Value = searchdata;
            }
            else
            {
                cmd = new SqlCommand("select* from table_feedback where email=@searchdata", conn);
                cmd.Parameters.Add("@searchdata", System.Data.SqlDbType.NVarChar);
                cmd.Parameters["@searchdata"].Value = searchdata;
            }
            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            List<FeedbackModel> feedbacks = new List<FeedbackModel>();
            while (rdr.Read())
            {
                FeedbackModel model = new FeedbackModel();
                model.contact = rdr["contact"].ToString();
                model.name = rdr["name"].ToString();
                model.id = Convert.ToInt32(rdr["id"]);
                model.email = rdr["email"].ToString();
                model.feedback = rdr["feedback"].ToString();
                feedbacks.Add(model);
            }
            return feedbacks;
        }
    }
}



