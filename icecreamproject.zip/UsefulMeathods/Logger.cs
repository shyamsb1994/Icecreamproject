﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Web.Mvc;
using Newtonsoft.Json;
namespace icecreamproject.UsefulMeathods
{
    public class Logger
    {
        public void WriteLog(object data)
        {
            string stringifieddata = null;
            try
            {
                stringifieddata = JsonConvert.SerializeObject(data);
            }
            catch (Exception e)
            {
                stringifieddata = JsonConvert.SerializeObject(e);
            }
            string path=HttpContext.Current.Server.MapPath("~/Logs/UserLogs.txt");
            
            System.IO.File.AppendAllText(path, stringifieddata.Insert(0, "\n\n"));
        }
    }
}