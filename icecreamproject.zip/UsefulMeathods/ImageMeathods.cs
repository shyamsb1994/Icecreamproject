﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace icecreamproject.UsefulMeathods
{
    public class ImageMeathods
    {
        public bool StoreImage(HttpPostedFileBase imgdata)
        {
            if (imgdata.FileName != null)
            {
                string storagepath = System.IO.Path.Combine(HttpContext.Current.Server.MapPath("~/images"), imgdata.FileName);
                imgdata.SaveAs(storagepath);
                return true;
            }
            return false;
        }
    }
}